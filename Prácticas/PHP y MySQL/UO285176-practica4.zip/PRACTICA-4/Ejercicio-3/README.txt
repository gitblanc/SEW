En este ejercicio, hay 4 advertencias con el css. Esto se debe a la colocación de la
label que identifica a la pantalla donde se muestra en numero a introducir en la pila.
Los warnings(4) están asociados a la redefinición de grid-row-start y grid-row-end.