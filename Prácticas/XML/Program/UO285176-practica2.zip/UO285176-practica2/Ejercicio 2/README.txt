Cada subcarpeta contiene el correspondiente programa y sus instrucciones e intérprete correspondientes.
De todas formas, se ha añadido también un pdf general del ejercicio 2 por si se quiere revisar el 
trabajo más en detalle.

Un saludo,
Eduardo Blanco Bielsa