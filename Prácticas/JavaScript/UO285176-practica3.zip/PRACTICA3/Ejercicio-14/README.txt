LA APLICACIÓN UTILIZA 3 API -> CANVAS, HISTORY y FULLSCREEN

La aplicación nos permite dibujar a Pacman, verlo a pantalla completa y 
retroceder o avanzar en la página