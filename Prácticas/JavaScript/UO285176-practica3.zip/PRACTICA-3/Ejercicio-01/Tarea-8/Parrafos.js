document.write("<p>","Otros datos de interés:","</p>")
document.write("<p>",subject.student,"</p>")
document.write("<p>",subject.year,"</p>")
document.write("<p>",subject.email,"</p>")