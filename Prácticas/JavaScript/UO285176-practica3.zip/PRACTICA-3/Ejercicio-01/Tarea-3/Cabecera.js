var subject = new Object();
subject.name = "Software y Estándares para la Web";
subject.degree = "Ingeniería Informática del Software";
subject.place = "Escuela de Ingeniería Informática";
subject.university = "Universidad de Oviedo";
subject.student = "Eduardo Blanco Bielsa"
subject.year = "2022-2023"
subject.email = "UO285176@uniovi.es"