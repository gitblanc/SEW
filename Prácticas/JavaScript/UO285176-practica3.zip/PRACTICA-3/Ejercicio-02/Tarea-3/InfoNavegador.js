var info = new Object();
info.nombre = navigator.appName;
info.idioma = navigator.language;
info.version = navigator.appVersion;
info.plataforma = navigator.platform;
info.vendedor = navigator.vendor;
info.agente = navigator.userAgent;
info.java = navigator.javaEnabled();